# CoE Strategy Analysis Agent

Generates a populated CoE Account Strategy Analysis Excel file from a Pre-Analysis Dashboard upload.

## Endpoint

### `GET /`
Health check. Returns `{"status": "ok"}`.

### `POST /analyze`
Upload a Pre-Analysis Dashboard file and receive the populated Strategy Analysis output.

**Request:**
- `Content-Type: multipart/form-data`
- Field: `file` — Pre-Analysis Dashboard `.xlsx`

**Response:**
- `Content-Type: application/vnd.ms-excel.sheet.macroEnabled.12`
- Attachment: `{account_label} — Strategy Analysis {date_range}.xlsm`

**Example (curl):**
```bash
curl -X POST https://<your-render-url>/analyze \
  -F "file=@67AD6B_-_US_-_HobaCare_-_seller_Pre_Analysis_Dashboard.xlsx" \
  -o "HobaCare_Strategy_Analysis.xlsm"
```

## Data Sources (from Pre-Analysis)

| Tab | Fields |
|-----|--------|
| `01_Advertiser_Name` | Account label, Tenant ID, Profile ID, date range |
| `55_Salesforce_Consolidated_PreA` | CSM name, objectives, priorities, CJM stages, Gong |
| `38_Client_Success_Insights_Repo` | Repeat purchase, sales concentration, CSM tenure, CAC |
| `54_Project_Dataset_on_SF` | CS Notes |
| `14_Campaign_Performance_by_Adve` | ASIN metrics, spend by campaign type, tags |
| `22_Catalogue_Details` | AOV, price tier, brand, department, category |

## Deployment

Hosted on Render. Deploy via GitHub push to `main` branch.
